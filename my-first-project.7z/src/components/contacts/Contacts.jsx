import React from 'react'

const Contacts = (props) => {
    console.log(props);
  return (
    <div>
        <h3>Sveikas prisijungęs, </h3>
        <p>{props.name}</p>
        <p>{props.email} </p>
        <p>{props.city} </p>
    </div>
  )
}

export default Contacts