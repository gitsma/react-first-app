import React from 'react'
import Contacts from '../contacts/Contacts'

const Header = () => {
  return (
    <div>
      <Contacts name="Gitana" email="gitana@gmail.com" city="Kaunas"/>
    </div>
  )
}

export default Header  