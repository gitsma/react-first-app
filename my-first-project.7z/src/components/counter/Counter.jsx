import React, {useState} from 'react';

const Counter = () => {
    /* [vieta kur saugosime nauja reiksme, metodas state atnaujinimui] = pradine inicial state reiksme nuo kurios startuojame */
    const [count, setCount] = useState(0);
  return (
    <div>
        <p>You clicked {count} times</p>
        <button 
        onClick={()=> setCount(count + 1)}>
        Increase count</button>
        <button 
        onClick={()=> setCount(count - 1)}>
        Decrease count</button>
    </div>
  )
}

export default Counter