import styles from "./Book.module.css";
import React from 'react'

const Book = () => {
  return (
    <div className={styles.oneBook}>
        <img className={styles.oneBookImg} src="https://thumb.knygos-static.lt/jg48gkygkUYZ9G_K8vRY17N_5SU=/fit-in/0x800/images/books/12228060/9781787017634.jpg" alt="" />
        <h2> The Travel Book</h2>
        <p>Lonely Planet: The world's leading travel guide publisher</p>
        <p>Kaina: 20Eur</p>
    </div>
  )
}

export default Book